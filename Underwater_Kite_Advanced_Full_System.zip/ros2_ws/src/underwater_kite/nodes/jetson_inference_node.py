import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32

class JetsonInference(Node):
    def __init__(self):
        super().__init__('jetson_inference_node')
        self.publisher_ = self.create_publisher(Float32, 'kite_power_output', 10)
        self.timer = self.create_timer(2.0, self.infer)

    def infer(self):
        power = 23.5  # Simulated power from Jetson model
        msg = Float32()
        msg.data = power
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published inferred power: {power}')

def main(args=None):
    rclpy.init(args=args)
    node = JetsonInference()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
