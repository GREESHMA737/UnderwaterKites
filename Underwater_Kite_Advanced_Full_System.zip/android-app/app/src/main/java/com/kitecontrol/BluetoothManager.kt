package com.kitecontrol

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.util.*

class BluetoothManager {
    private val adapter: BluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

    fun connectToDevice(address: String): BluetoothSocket? {
        val device: BluetoothDevice = adapter.getRemoteDevice(address)
        val uuid: UUID = device.uuids[0].uuid
        return device.createRfcommSocketToServiceRecord(uuid)
    }
}
