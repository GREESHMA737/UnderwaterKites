package com.kitecontrol

import android.util.Log
import org.eclipse.paho.client.mqttv3.*

class MQTTManager(brokerUrl: String, clientId: String) {
    private val client = MqttClient(brokerUrl, clientId, null)

    fun connect() {
        val options = MqttConnectOptions()
        options.isCleanSession = true
        client.connect(options)
        Log.d("MQTT", "Connected to broker")
    }

    fun publish(topic: String, message: String) {
        val msg = MqttMessage(message.toByteArray())
        client.publish(topic, msg)
    }
}
