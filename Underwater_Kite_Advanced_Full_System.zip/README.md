# Advanced Underwater Kite System
Includes Unity simulation, ROS2 Jetson inference, and Android MQTT/Bluetooth control.