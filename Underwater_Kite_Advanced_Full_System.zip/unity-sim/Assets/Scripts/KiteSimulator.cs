using UnityEngine;

public class KiteSimulator : MonoBehaviour {
    public float speed = 5.0f;

    void Update() {
        transform.position += Vector3.forward * speed * Time.deltaTime;
    }
}
